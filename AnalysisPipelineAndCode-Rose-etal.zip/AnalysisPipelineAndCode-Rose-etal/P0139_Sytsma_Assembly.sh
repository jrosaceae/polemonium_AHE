#########################
#CHECK Anchor_Sequencing/LemmonSequencingPlan.xlsx to make sure that only one lane needs to be considered.
#########################

#################### SETUP TAXSET ##########################

#########VARIABLES#############
#COLLAB = Sytsma = Collaborator's name
#FILEPATH = Alan_Lemmon-07-13-2017_Sytsma1A-Sytsma1B = The Filepath on the rcc server to where the raw read data is located.
#PXXXX = P0139 = Project Number
#BEGIND = 23842 = The first I# folder within the Assembly folder; don't include the "I"
#ENDIND = 23962 = The last I# folder within the Assembly folder; don't include the "I"
#LANENUM = 1 = The lane number that the samples were sequenced on
#REFNAME = Angiosperm = Name of to folder containing the Reference sequences being used to assemble reads
#MERGEJOBS = MERGE.JOBS = Number of Jobs running during Merge Program, e.g. typically 5.
#ASSEMBLEDLOCI = 517 = Number of Loci the reference sequences contain.
#NTHREADS = 16 = Number of threads/scripts used to run assemblies.
#REFNUM = 3 = Number of Reference individuals used in assembly.
#NSCRIPTS = 20 = Number of Scripts written to be exectued. Used for paralellizing.
#NTAXA = 121 = Number of samples
#SEQDATE = 2017-07-13 = Date samples were sequenced
#LINUX = LIN.UX = Last 3 digits of IP adress of machine that the Assembly is stored on
#STORNUM = 41 = Storage number that the Assembly is stored on
#DRIVENAME = P0139_Sytsma = Drive that the Assembly will be offloaded to



###IF YOU DEVIATE FROM THIS TEMPLATE WRITE DOWN ANY CHANGES######



################ MEDICINE SERVER ################
#Connect to medicine server and determine the correct file path
ssh alemmon@hpc-login.rcc.fsu.edu
cd /lustre/medicine/sequencer/Outputs_CASAVA/2017_Outputs/
#fIND AND REPLACE COLLABORATOR NAME HERE
Sytsma
ls -d Alan*
#FIND AND REPLACE THE FILEPATH HERE
Alan_Lemmon-07-13-2017_Sytsma1A-Sytsma1B
cd Alan_Lemmon-07-13-2017_Sytsma1A-Sytsma1B
ls -1 
#FIND AND REPLACE THE PROJECT NUMBER HERE 
P0139
cd Project_P0139
ls -1 
#REPLACE BEGINNING NUMBER AND ENDING NUMBER HERE
23842
23962
#EXIT OUT OF THE SSH
exit

################ DOWNLOAD ################ 
#MAKE SURE YOU ARE IN A STORAGE FOLDER
mkdir P0139_Sytsma
cd P0139_Sytsma
#Systsma Samples from SytsmaA-SytsmaB FlowCell
rsync -av --progress alemmon@hpc-login.rcc.fsu.edu:/lustre/medicine/sequencer/Outputs_CASAVA/2017_Outputs/Alan_Lemmon-07-13-2017_Sytsma1A-Sytsma1B/Project_P0139/ .
#Sytsma Samples from JamesCheSytsma Misc Lane
rsync -av --progress alemmon@hpc-login.rcc.fsu.edu:/lustre/medicine/sequencer/Outputs_CASAVA/2017_Outputs/Alan_Lemmon-07-13-2017_JamesCheSytsma-Che5Redo/Project_P0139/ .

mkdir Undetermined_indices
mkdir OriginalRawReads
mkdir Results
mkdir Code
rsync -av --progress '/home/alemmon/Dropbox/Anchor_Bioinformatics/Code/AllelePhaser3.class' '/home/alemmon/Dropbox/Anchor_Bioinformatics/Code/AllelePhaserRead.class' '/home/alemmon/Dropbox/Anchor_Bioinformatics/Code/WriteMergeScript.class' '/home/alemmon/Dropbox/Anchor_Bioinformatics/Code/WriteAllelePhaserScript.class' '/home/alemmon/Dropbox/Anchor_Bioinformatics/Code/AllelePhaserRead.class' '/home/alemmon/Dropbox/Anchor_Bioinformatics/Code/AllelePhaser3.class' '/home/alemmon/Dropbox/Anchor_Bioinformatics/Code/WriteMergeScript.class' '/home/alemmon/Dropbox/Anchor_Bioinformatics/Code/ProfileUndeterminedIndexes.class' '/home/alemmon/Dropbox/Anchor_Bioinformatics/Code/MergeThread.class' '/home/alemmon/Dropbox/Anchor_Bioinformatics/Code/MergeNode.class' '/home/alemmon/Dropbox/Anchor_Bioinformatics/Code/Merge$1.class' '/home/alemmon/Dropbox/Anchor_Bioinformatics/Code/Merge.class' '/home/alemmon/Dropbox/Anchor_Bioinformatics/Code/WriteAssemblerScript.class' '/home/alemmon/Dropbox/Anchor_Bioinformatics/Code/SuperContig.class' '/home/alemmon/Dropbox/Anchor_Bioinformatics/Code/Read.class' '/home/alemmon/Dropbox/Anchor_Bioinformatics/Code/Nmer.class' '/home/alemmon/Dropbox/Anchor_Bioinformatics/Code/Kmer.class' '/home/alemmon/Dropbox/Anchor_Bioinformatics/Code/Contig.class' '/home/alemmon/Dropbox/Anchor_Bioinformatics/Code/Assembler.class' '/home/alemmon/Dropbox/Anchor_Bioinformatics/Code/AlignedRead.class' '/home/alemmon/Dropbox/Anchor_Bioinformatics/Code/ExtractAssemblySummary2.class' '/home/alemmon/Dropbox/Anchor_Bioinformatics/Code/PlotConSeqLengths.r' '/home/alemmon/Dropbox/Anchor_Bioinformatics/Code/ExtractNMapped.class' '/home/alemmon/Dropbox/Anchor_Bioinformatics/Code/MoveToMasterDrive.sh' Code

#ONCE DOWNLOAD IS COMPLETE, OPEN SEQUENCING PLAN ON A MAC AND CHANGE COLOR TO GREEN. IF YOU OPEN AND SAVE ON LINUX THE FILE WILL BE CORRUPTED


################ SETUP ################
cd Code
rsync -av --progress ../Sample* ../OriginalRawReads/.

#Once Downloaded and backed up, files were split up across 3 computers because samples are time sensitive for student graduations
#Linux6 -- I#{23938..23962}
#Linux2 -- I#{23842..23889}
#Linux4 -- I#{23890..23937}

#Linux 2
rm ../Sample*/SampleSheet.csv
for i in {23842..23889}; do mv ../Sample_P0139_*_I$i ../I$i; done

gunzip -r ../I*

#Linux 4
rm ../Sample*/SampleSheet.csv
for i in {23890..23937}; do mv ../Sample_P0139_*_I$i ../I$i; done

gunzip -r ../I*

#Linux 6
rm ../Sample*/SampleSheet.csv
for i in {23938..23962}; do mv ../Sample_P0139_*_I$i ../I$i; done

gunzip -r ../I*

################ MERGING ################ 
#java WriteMergeScript Merge BEGIND ENDIND RAM MERGEJOBS

#Linux2
java WriteMergeScript P0139 23842 23889 2000 24

chmod +x Merge*.sh
for i in {1..24}; do run-in-new-tab ./Merge_P0139_${i}.sh; done;

#Linux4
java WriteMergeScript P0139 23890 23937 2000 24

chmod +x Merge*.sh
for i in {1..24}; do run-in-new-tab ./Merge_P0139_${i}.sh; done;

#Linux6
java WriteMergeScript P0139 23938 23962 2000 24

chmod +x Merge*.sh
for i in {1..24}; do run-in-new-tab ./Merge_P0139_${i}.sh; done;


################ CREATE MERGED READ DISTRUBTION FILES #############################
R
for(i in 23938:23962){
	print(i)
	if(!file.exists(paste("../I",i,"/I",i,"_lengths.txt",sep=""))){next}
	pdf(paste("../I",i,"/I",i,"_lengths.pdf",sep=""))
	plot(scan(paste("../I",i,"/I",i,"_lengths.txt",sep=""))[1:299],type="l",main=paste("I",i,sep=""),xlab="Length of Merged Read",ylab="Number of Merged Reads")
	dev.off()
}

q()
n

R
for(i in 23890:23937){
	print(i)
	if(!file.exists(paste("../I",i,"/I",i,"_lengths.txt",sep=""))){next}
	pdf(paste("../I",i,"/I",i,"_lengths.pdf",sep=""))
	plot(scan(paste("../I",i,"/I",i,"_lengths.txt",sep=""))[1:299],type="l",main=paste("I",i,sep=""),xlab="Length of Merged Read",ylab="Number of Merged Reads")
	dev.off()
}

q()
n

R
for(i in 23842:23889){
	print(i)
	if(!file.exists(paste("../I",i,"/I",i,"_lengths.txt",sep=""))){next}
	pdf(paste("../I",i,"/I",i,"_lengths.pdf",sep=""))
	plot(scan(paste("../I",i,"/I",i,"_lengths.txt",sep=""))[1:299],type="l",main=paste("I",i,sep=""),xlab="Length of Merged Read",ylab="Number of Merged Reads")
	dev.off()
}

q()
n


pdfunite ../I*/*_lengths.pdf ../Results/All_lengths.pdf
#Inspect read length distribution
evince ../Results/All_lengths.pdf

################ REFERENCES ################
#WHICH REFERENCES WOULD YOU LIKE TO USE?
Angiosperm
mkdir ../References
rsync -av --progress /home/alemmon/Dropbox/Anchor_Bioinformatics/References/Angiosperm_References/* ../References/.

#find assembled loci
wc -l ../References/*.seqs
517

#find ref number in ../References/REFRefs.txt
3

################ ASSEMBLIES ################
#projectID begInd endInd ReferenceName nRefs ASSEMBLEDLOCI ramMB nScripts
#LINUX6
java WriteAssemblerScript P0139 23938 23962 AngiospermRefs 3 517 16000 16	
chmod +x Assemble*.sh
for i in {1..16}; do
    run-in-new-tab ./Assemble_P0139_${i}.sh
done

#LINUX4
java WriteAssemblerScript P0139 23890 23937 AngiospermRefs 3 517 16000 16	
chmod +x Assemble*.sh
for i in {1..16}; do
    run-in-new-tab ./Assemble_P0139_${i}.sh
done

#LINUX2
java WriteAssemblerScript P0139 23842 23889 AngiospermRefs 3 517 16000 16	
chmod +x Assemble*.sh
for i in {1..16}; do
    run-in-new-tab ./Assemble_P0139_${i}.sh
done

#MOVE EVERYTHING BACK TO ONE COMPUTER FOR SUMMARY ANALYSIS
################ SUMMARY ANALYSES ################
java -Xmx8000m ExtractAssemblySummary2 23842 23962 517 ../Results/P0139_AssemblySummary 


#HOW MANY TAXA ARE THERE IN THIS DATASET?
121


R
source("PlotConSeqLengths.r")
#makePlot("P0139",121,517,517, minReads minLength maxReads maxLength slope) 
makePlot("P0139",121,517,517,10,200,6000,2500,0.25) 

quit()
n

#NOW COMPUTE INDIVIDUAL-SPECIFIC NMAPPED FILES
java ExtractNMapped 23895 23962 


################ ALLELE PHASING ################
#ALLELE PHASING IS ALWAYS NECESSSARY
#java WriteAllelePhaserScript projectID begInd endInd nScripts
java WriteAllelePhaserScript P0139 23842 23962 20
chmod +x AllelePhase*.sh
for i in {1..20}; do
    run-in-new-tab ./AllelePhase_P0139_${i}.sh
done


#WHO IS THE COLLABORATOR
Sytsma
#WHAT DATE WERE THESE SAMPLES SEQUENCED -- use sequencing plan? (yyyy-mm-dd)
2017-07-13

#MAKE RESULTS FOLDER AND SAVE TO DROPBOX
mkdir /home/alemmon/Dropbox/Anchor_Bioinformatics/Results/P0139_Sytsma/2017-07-13

rsync -av --progress ../Results/P0139_AssemblySummary_conSeqLens.pdf ../Results/P0139_AssemblySummary_conSeqLensUpper.pdf ../Results/P0139_AssemblySummary_nLociCaptured.pdf ../Results/P0139_AssemblySummary_maxLocNumb.pdf ../Results/P0139_AssemblySummary_Summary.txt ../Results/P0139_AssemblySummary_Summary.xlsx /home/alemmon/Dropbox/Anchor_Bioinformatics/Results/P0139_Sytsma/2017-07-13


################ OFFLOAD ################
#OFFLOAD TO PROJECT DRIVE
rsync -av --progress  '/media/alemmon/storage41/P0139_Sytsma/' 'alemmon@128.186.21.179:/Volumes/P0139_Sytsma/2017-07-13'

#OFFLOAD TO MASTERDRIVE
#Plug in Master Drive and ensure drive is mounted properly. 
#./MoveToMasterDrive.sh PXXXX BEGIND ENDIND 'Anchor!Q@W'
./MoveToMasterDrive.sh P0139 23842 23962 'Anchor!Q@W'

