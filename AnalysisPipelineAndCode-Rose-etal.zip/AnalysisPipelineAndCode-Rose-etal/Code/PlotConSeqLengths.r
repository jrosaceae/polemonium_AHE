makePlot<<-function(project,ntaxa,nloci,nlociPossible,minReads,minLen,maxReads,yint,slope){
	blah1<<-read.table(paste("../Results/",project,"_AssemblySummary_conSeqLensUpper.txt",sep="",collapse=""),skip=2,nrow=ntaxa)
	blah2<<-read.table(paste("../Results/",project,"_AssemblySummary_conSeqLensUpper.txt",sep="",collapse=""),skip=ntaxa+5,nrow=ntaxa)

	lower1<<-read.table(paste("../Results/",project,"_AssemblySummary_conSeqLensLower.txt",sep="",collapse=""),skip=2,nrow=ntaxa)

	nBases1<<-as.matrix(blah1[,2:(nloci+1)])+as.matrix(lower1[,2:(nloci+1)])

	nReads1<<-read.table(paste("../Results/",project,"_AssemblySummary_nMappedReads.txt",sep="",collapse=""),skip=2,nrow=ntaxa)
	nReads2<<-read.table(paste("../Results/",project,"_AssemblySummary_nMappedReads.txt",sep="",collapse=""),skip=ntaxa+5,nrow=ntaxa)

	

#pdf(paste("../Results/",project,"_AssemblySummary_readsVsLens.pdf",sep="",collapse=""))
	quartz()
	plot(as.matrix(nReads1[,2:(nloci+1)]),nBases1,cex=0.1)#cex=0.1,xlim=c(0,quantile(as.matrix(nReads1[,2:(nloci+1)]),0.99)),ylim=c(0,quantile(nBases1,0.99)))
	lines(c(minReads,maxReads,maxReads,minReads),c(minLen,minLen,maxReads*slope+yint,minReads*slope+yint),col="red")
	#dev.off()
	
	pdf(paste("../Results/",project,"_AssemblySummary_conSeqLensUpper.pdf",sep="",collapse=""))
	plot(-9999,-9999,xlim=c(0.5,ntaxa+0.5),ylim=c(-75,4000),xlab="Sample",ylab="Consensus Sequence Length",main=paste("Assembly Results - ",project,sep="",collapse=""),cex=0.1)
	GURR<<-0
	for(i in 1:ntaxa){
		points(rep(i,nloci)+runif(nloci,-0.25,0.25),pmax(as.numeric(blah1[i,2:(nloci+1)]),as.numeric(blah2[i,2:(nloci+1)])),cex=0.2)
		GURR<<-c(GURR,pmax(as.numeric(blah1[i,2:(nloci+1)]),as.numeric(blah2[i,2:(nloci+1)])))
		text(i,-300+(i%%2)*200,blah1[i,1],cex=0.3,srt=90)
		#points(rep(i,nloci)+runif(nloci,-0.25,0.25),-as.numeric(blah2[i,2:(nloci+1)]),cex=0.5)
	}
	
	dev.off()
	pdf(paste("../Results/",project,"_AssemblySummary_conSeqLens.pdf",sep="",collapse=""))
	hist(GURR[GURR>0],breaks=seq(-0.5,max(GURR)+50.5,50),xlim=c(0,4000),xlab="Length",ylab="Number of Consensus Sequences",col="yellow",main=paste("Assembly Results - ",project,sep="",collapse=""))
	dev.off()
	
	write(GURR,file=paste("../Results/",project,"_AllLens.txt",sep="",collapse=""),ncol=1)
	
	blah3<<-read.table(paste("../Results/",project,"_AssemblySummary_Summary.txt",sep="",collapse=""),skip=1,sep="\t")	
	pdf(paste("../Results/",project,"_AssemblySummary_nLociCaptured.pdf",sep="",collapse=""))
	plot(-9999,-9999,xlim=c(0.5,ntaxa+0.5),ylim=c(-25,nlociPossible+75),xlab="Sample",ylab="Number of loci Captured",main=paste("Assembly Results - ",project,sep="",collapse=""))
	lines(c(0,ntaxa),c(nlociPossible,nlociPossible),lwd=2,col="gray")

	write(GURR,file=paste("../Results/",project,"_AllLens.txt",sep="",collapse=""),ncol=1)
	write(blah3[,16],file=paste("../Results/",project,"_nLoci250.txt",sep="",collapse=""),ncol=1)
	write(blah3[,17],file=paste("../Results/",project,"_nLoci500.txt",sep="",collapse=""),ncol=1)
	write(blah3[,18],file=paste("../Results/",project,"_nLoci1000.txt",sep="",collapse=""),ncol=1)

	text(ntaxa,nloci+50,">125bp",col="blue",cex=0.75)
	text(ntaxa,nloci+35,">250bp",col="green",cex=0.75)
	text(ntaxa,nloci+20,">500bp",col="orange",cex=0.75)
	text(ntaxa,nloci+05,">1000bp",col="red",cex=0.75)

	points(1:ntaxa,blah3[,18],pch=19,col="red")
	lines(1:ntaxa,blah3[,18],col="red",lwd=2)

	points(1:ntaxa,blah3[,17],pch=19,col="orange")
	lines(1:ntaxa,blah3[,17],col="orange",lwd=2)

	points(1:ntaxa,blah3[,16],pch=19,col="green")
	lines(1:ntaxa,blah3[,16],col="green",lwd=2)

	points(1:ntaxa,blah3[,15],pch=19,col="blue")
	lines(1:ntaxa,blah3[,15],col="blue",lwd=2)

	for(i in 1:ntaxa){
		text(i,-20+(i%%2)*20,blah3[i,1],cex=0.3,srt=90)
		#points(rep(i,nloci)+runif(nloci,-0.25,0.25),-as.numeric(blah2[i,2:(nloci+1)]),cex=0.5)
	}
	dev.off()

	pdf(paste("../Results/",project,"_AssemblySummary_maxLocNumb.pdf",sep="",collapse=""))
#quartz()
	maxLocID<<-as.matrix(nReads1[,2:(nloci+1)])
	maxLocID[maxLocID>0]=1
	plot(1:ntaxa,apply(t(t(maxLocID)*(1:nloci)),1,max),xlim=c(0,ntaxa), ylim=c(0,nloci),pch=19,cex=0.5)
#	for(i in 1:ntaxa){
		text(1:ntaxa,apply(t(t(maxLocID)*(1:nloci)),1,max)-20,blah3[1:ntaxa,1],cex=0.5,srt=90)
#		#points(rep(i,nloci)+runif(nloci,-0.25,0.25),-as.numeric(blah2[i,2:(nloci+1)]),cex=0.5)
#	}
	dev.off()
	
	
}
