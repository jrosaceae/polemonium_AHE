//java WriteMergeScript P0090 10165 10167 2000 10

import java.io.*;

public class WriteMergeScript{

  public static void main(String[] args){
    try{

		
		String project = args[0];							//e.g. P0032
		int begSample = Integer.parseInt(args[1]);			//e.g. 2859
		int endSample = Integer.parseInt(args[2]);			//e.g. 2866
		int ram = Integer.parseInt(args[3]);				//e.g. 8000
		int jobs = Integer.parseInt(args[4]);				//e.g. 3

		int nInds=0;
		for(int i=begSample; i<=endSample; i++){
			String ind=getSampleName(i);
			String filename="../"+ind;
			if(new File(filename).exists()){
		 		nInds++;
			}
		}
		int jobSize=(int)(Math.ceil(nInds/(double)jobs));//truncation desired

		BufferedWriter bw=null;
		nInds=0;
		int nOutfiles=0;

		for(int i=begSample; i<=endSample; i++){
			String ind=getSampleName(i);
			String filename="../"+ind;
			if(new File(filename).exists()){
		 		nInds++;
				if(nInds%jobSize==1 || jobSize==1){
					if(bw!=null){bw.flush(); bw.close();}
					nOutfiles++;
					bw = new BufferedWriter ( new OutputStreamWriter(new FileOutputStream(   new File("Merge_"+project+"_"+nOutfiles+".sh") ) ));
				}
				String[] parts = ind.split("I");
				String part1 = parts[1];
				bw.write("java -Xmx"+ram+"m Merge "+parts[1]+" "+parts[1]+" 5\n");
				bw.flush();
			}
		}		
		bw.flush();
		bw.close();

    }catch(IOException ioe){System.out.println(ioe);}
  }

  static String getSampleName(int i){
  	String sampleName;
	if(i<10){sampleName="I000"+i;
	}else if(i<100){sampleName="I00"+i;
	}else if(i<1000){sampleName="I0"+i;
	}else{sampleName="I"+i;}
	return sampleName;
  }
}
