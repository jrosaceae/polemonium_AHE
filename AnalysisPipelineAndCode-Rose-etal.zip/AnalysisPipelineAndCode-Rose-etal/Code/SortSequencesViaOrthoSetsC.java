import java.io.*;
import java.util.*;
import java.util.HashMap;
//VERSION B allows the user to utilize conSeqs, any of the phased allele sets. It also deals with the changover to the Taxon set number system (does not use the Project number)
////////////////////////////////////
//THIS PROGRAM TAKES THE ORTHO SET INFORMATION AND CREATES NEW conSeq FILES FOR EACH INDIVIDUAL THAT CAN BE USED IN THE GetPairwiseDistanceMeasures.java program
////////////////////////////////////

public class SortSequencesViaOrthoSetsC{
  public static void main(String[] args){
      try{

		String taxonSet = args[0];							//e.g. T1
		String seqFileSpec = args[1];					//e.g. T1_PloidySpecificationFile.txt
		int minSeqsInOrthoSet = Integer.parseInt(args[2]);	//e.g. 25
		int nAlignmentScripts = Integer.parseInt(args[3]);	//e.g. 8
		String folderTail="";
		if(args.length>4){folderTail=args[4];}			//e.g. _2alleles or _conSeqs or _mixturePloidy

		//COUNT THE NUMBER OF LOCI (MAXIMUM OBSERVED)
		int nLoci=0;
		for(int loc=1; loc<100000; loc++){
			if(new File("../OrthoSets/"+taxonSet+"_L"+loc+".txt").exists()){nLoci=loc;}
		}
		System.out.println(nLoci+" loci found.");
		if(nLoci==0){return;}
		
		//COUNT THE NUBMER OF TAXA IN THE TAXON SET, AND CHECK TO SEE IF ANY ARE MISSING
		BufferedReader brT = new BufferedReader ( new InputStreamReader(new FileInputStream(   new File("../"+taxonSet+".txt") ) ));
		String tempT=brT.readLine();	//e.g. I0463_Squamata_Teiidae_Tupinambis_merianae_FG059
		int nTaxa=0;
		while(tempT!=null){
			String tax=tempT.split("_")[0];
			if(!new File("../"+tempT.split("_")[0]).exists()){System.out.println("WARNING: Taxon "+tempT+" not found!");}
			nTaxa++;
			tempT=brT.readLine();
		}
		brT.close();	
		
		//obtain the taxon names from the taxon set file, need this to fill in missing taxa before alignment step		
		String taxa[] = new String[nTaxa];
		brT = new BufferedReader ( new InputStreamReader(new FileInputStream(   new File("../"+taxonSet+".txt") ) ));
		for(int i=0; i<nTaxa; i++){
			taxa[i]=brT.readLine();	//e.g. I2982_CER85.2_Gobiidae_Chlamydogobius_eremius
		}
		brT.close();

		//obtain the ploidy specification (list of sequence files to use)
		String seqFiles[] = new String[nTaxa];
		brT = new BufferedReader ( new InputStreamReader(new FileInputStream(   new File(seqFileSpec) ) ));
		int ploidy[] = new int[nTaxa];
		for(int i=0; i<nTaxa; i++){
			seqFiles[i]=brT.readLine().split("\t")[0];	//e.g. I2982_allelesFromPost_2.txt

			BufferedReader brP = new BufferedReader ( new InputStreamReader(new FileInputStream(   new File("../"+taxa[i].split("_")[0]+"/"+seqFiles[i] )) ));
			//open up each file and determine the ploidy
			String tempP = brP.readLine();	//first header
			if(tempP.split("\\.").length==2){ploidy[i]=1; continue;}
			while(tempP!=null){
				ploidy[i]=Math.max(ploidy[i],Integer.parseInt(tempP.split("\\.")[2]));
				tempP=brP.readLine();	//sequence
				tempP=brP.readLine();	//next header
			}
		}
		brT.close();		

		//CREATE THE DIRECTORY STRUCTURE FOR BOTH THE PREALIGNMENTS AND THE ALIGNMENTS
		new File("../Prealignments"+folderTail).mkdir();
		new File("../Alignments"+folderTail).mkdir();

		//Setup conversion file
		BufferedWriter bwKey = new BufferedWriter ( new OutputStreamWriter(new FileOutputStream(   new File("../Prealignments"+folderTail+"/LocusConversionKEY.sh") ) ));	//out file
		bwKey.write("OldLocNumb\tNewLocNumb\n");
		
		int nLociNew=0;
		for(int loc=1; loc<=nLoci; loc++){
System.out.println("L"+loc);
			if(!new File("../OrthoSets/"+taxonSet+"_L"+loc+".txt").exists()){continue;}
			BufferedReader br2 = new BufferedReader ( new InputStreamReader(new FileInputStream(   new File("../OrthoSets/"+taxonSet+"_L"+loc+".txt") ) ));	//file with ortho set IDS.
			//determine how many orthologs sets there could be for this locus
			String tempS2=br2.readLine();
			int currValue=0;
			int max=0;
			while(tempS2!=null){
				currValue=Integer.parseInt(tempS2);
				if(currValue>max){max=currValue;}
				tempS2=br2.readLine();
			}
			br2.close();

			//go through file again and tally up number of seqs in each set
			int tally[] = new int[max];
			br2 = new BufferedReader ( new InputStreamReader(new FileInputStream(   new File("../OrthoSets/"+taxonSet+"_L"+loc+".txt") ) ));	//file with ortho set IDS.
			tempS2=br2.readLine();			
			while(tempS2!=null){
				currValue=Integer.parseInt(tempS2);
				tally[currValue-1]++;
				tempS2=br2.readLine();
			}
			br2.close();

			//create outfiles
			BufferedWriter bw[] = new BufferedWriter[max];
			BufferedWriter bwKeys[] = new BufferedWriter[max];

			for(int i=0; i<max; i++){
				if(tally[i]>=minSeqsInOrthoSet){
					nLociNew++;
					bw[i] = new BufferedWriter ( new OutputStreamWriter(new FileOutputStream(   new File("../Prealignments"+folderTail+"/"+taxonSet+"_L"+nLociNew+".fasta") ) ));	//out file
					bwKeys[i] = new BufferedWriter ( new OutputStreamWriter(new FileOutputStream(   new File("../Prealignments"+folderTail+"/"+taxonSet+"_L"+nLociNew+"_keys.txt") ) ));	//out file
					bwKey.write(loc+"\t"+nLociNew+"\n");
				}
			}


			//TRANSFER SEQUENCES TO PREALIGNMENTS FILES
			//open taxon set file
			brT = new BufferedReader ( new InputStreamReader(new FileInputStream(   new File("../"+taxonSet+".txt") ) ));	
			tempT=brT.readLine();	//e.g. I0463_Squamata_Teiidae_Tupinambis_merianae_FG059
			int taxonIndex=-1;
			while(tempT!=null){
				String taxonID=tempT.split("_")[0];
				String taxonName=tempT;
				taxonIndex++;
				//for each taxon, attempt to identify it in the homolog file (if not found, then need to write appropriate number of missing sequences - based on nalleles determined by end of seqFileTail)
				boolean foundTaxon[] = new boolean[max];	//need to account for all possible orthosets
				BufferedReader brH = new BufferedReader ( new InputStreamReader(new FileInputStream(   new File("../Homologs/"+taxonSet+"_L"+loc+".fasta") ) ));	
				String tempH=brH.readLine();
				BufferedReader brO = new BufferedReader ( new InputStreamReader(new FileInputStream(   new File("../OrthoSets/"+taxonSet+"_L"+loc+".txt") ) ));	
				String tempO=brO.readLine();
				
				while(tempH!=null){
					int copyID=Integer.parseInt(tempH.substring(tempH.lastIndexOf("_Copy")+5));

					if(tempH.substring(1,tempH.lastIndexOf("_Copy")).equals(tempT)){

						//for each matching homolog found, look up the corresponding ortho set ID						
						int orthoID=Integer.parseInt(tempO);
						
						//if the bw file corresponding to that ortho set ID is not null, then it is valid
						if(bw[orthoID-1]!=null){
							//open the file containing the consensus or allele sequences for that ind
							int taxonIDIndex=-1;
							for(int x=0; x<nTaxa; x++){
								if(seqFiles[x].split("_")[0].equals(taxonID)){
									taxonIDIndex=x;
									break;
								}
							}
							if(taxonIDIndex==-1){System.out.println("ERROR: Your seqSpecFile does not contain the taxon "+taxonID); return;}
							BufferedReader brS = new BufferedReader ( new InputStreamReader(new FileInputStream(   new File("../"+taxonID+"/"+seqFiles[taxonIDIndex]) ) ));	//file with sequences
							String tempS = brS.readLine(); //e.g. >L1.1 or >L1.1.1
							int seqCounter=0;
							while(tempS!=null){
								String tempSeq=brS.readLine();
								//write all sequences corresponding to that locus and copy number to the file, with header matching	
								if(tempS.equals(">L"+loc+"."+copyID) || tempS.startsWith(">L"+loc+"."+copyID+".")){
									foundTaxon[orthoID-1]=true;
									seqCounter++;
									bwKeys[orthoID-1].write(taxonName+"\t"+copyID+"\n");
									bw[orthoID-1].write(">"+taxonName+"_seq"+seqCounter+"\n"+tempSeq+"\n");
								}
								tempS=brS.readLine(); //next header
							}
							brS.close();
						}
					
					}
					tempH=brH.readLine();	//homolog sequence
					tempO=brO.readLine();	//next orthoID
					tempH=brH.readLine();	//next homolog header		
				}
				brH.close();
				brO.close();
				
				//fill in missing sequences
				for(int i=0; i<max; i++){
					if(bw[i]!=null && !foundTaxon[i]){
						for(int a=1; a<=ploidy[taxonIndex]; a++){
							bwKeys[i].write(taxonName+"\t"+"seq"+a+"\tNA\n");
							bw[i].write(">"+taxonName+"_seq"+a+"\n"+"N"+"\n");

						}
					}
				}
				tempT=brT.readLine();
			}
			brT.close();
			for(int i=0; i<max; i++){
				if(bw[i]!=null){
					bw[i].flush();
					bw[i].close();

					bwKeys[i].flush();
					bwKeys[i].close();
				}
			}		
			
		}
		bwKey.flush();
		bwKey.close();		

		System.out.println(""+nLociNew+" orthologus loci with >= "+minSeqsInOrthoSet+" taxa were found.");

		BufferedWriter bwX[] = new BufferedWriter[nAlignmentScripts];
		for(int i=1; i<=nAlignmentScripts; i++){
			bwX[i-1] = new BufferedWriter ( new OutputStreamWriter(new FileOutputStream(   new File("Align_AllViaMAFFT"+folderTail+"_"+i+".sh") ) ));	//out file
			bwX[i-1].write("unset MAFFT_BINARIES\n");
		}
		for(int i=0; i<nLociNew; i++){
			if(new File("../Prealignments"+folderTail+"/"+taxonSet+"_L"+(i+1)+".fasta").exists()){
				bwX[i%nAlignmentScripts].write("mafft --genafpair --maxiterate 1000 --quiet ../Prealignments"+folderTail+"/"+taxonSet+"_L"+(i+1)+".fasta > ../Alignments"+folderTail+"/"+taxonSet+"_L"+(i+1)+".fasta\n");
			}
		}
		for(int i=0; i<nAlignmentScripts; i++){		
			bwX[i].flush();
			bwX[i].close();
		}


      }catch(IOException ioe){System.out.println("<<!!ERROR main()!!>>"+ioe.getMessage());}
  }

}

