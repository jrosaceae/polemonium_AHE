#THIS VERSION WORKS WITH *nMapped.txt FILES PRESENT IN EACH INDIVIDUAL'S FOLDER INSTEAD OF AN ASSEMBLY SUMMARY FILE
identifyGoodSeqs<<-function(begInd,endInd,nHomologs,minReadsMapped){

	nMapped1<<-0
	nMapped2<<-0
	nMapped3<<-0
	nMapped4<<-0
	nMapped5<<-0
	nMapped6<<-0
	firstWrite=T
	for(i in 1:nHomologs){
		nInd=0
		for(ind in begInd:endInd){
#print(i)
#print(ind)
			if(!file.exists(paste("../I",ind,"/I",ind,"_nMapped.txt",collapse="",sep=""))){next}
			nInd=nInd+1
			blah<<-read.table(paste("../I",ind,"/I",ind,"_nMapped.txt",collapse="",sep=""))
			goodLoci=blah[blah[,3]>=minReadsMapped & blah[,2]==i,1]
			towrite=cbind(rep(i,length(goodLoci)),rep(ind,length(goodLoci)),goodLoci)
			if(length(towrite)>0){
				write(t(towrite),ncol=3,sep="\t",file="../Results/GoodConSeqIDs.txt",append=!firstWrite)
				firstWrite=F
			}			

			if(i==1){	nMapped1<<-c(nMapped1,blah[blah[,2]==i,3])
			}else if(i==2){	nMapped2<<-c(nMapped2,blah[blah[,2]==i,3])
			}else if(i==3){	nMapped3<<-c(nMapped3,blah[blah[,2]==i,3])
			}else if(i==4){	nMapped4<<-c(nMapped4,blah[blah[,2]==i,3])
			}else if(i==5){	nMapped5<<-c(nMapped5,blah[blah[,2]==i,3])
			}else if(i==6){	nMapped6<<-c(nMapped6,blah[blah[,2]==i,3])
			}

		}

	}

	breaks=hist(c(log10(nMapped1),log10(nMapped2),log10(nMapped3),log10(nMapped4),log10(nMapped5),log10(nMapped6)),nclass=200,plot=F)$breaks
	line1=hist(log10(nMapped1),breaks=breaks,plot=F)$counts
	line2=hist(log10(nMapped2),breaks=breaks,plot=F)$counts
	line3=hist(log10(nMapped3),breaks=breaks,plot=F)$counts
	line4=hist(log10(nMapped4),breaks=breaks,plot=F)$counts
	line5=hist(log10(nMapped5),breaks=breaks,plot=F)$counts
	line6=hist(log10(nMapped6),breaks=breaks,plot=F)$counts

	plot(-999,-999,xlim=range(breaks),ylim=c(0,max(line1)),xlab="log10(nMapped)",ylab="frequency")
	lines(breaks[1:(length(breaks)-1)],line1,col="gray0",lwd=2)
	lines(breaks[1:(length(breaks)-1)],line2,col="gray15")
	lines(breaks[1:(length(breaks)-1)],line3,col="gray30")
	lines(breaks[1:(length(breaks)-1)],line4,col="gray45")
	lines(breaks[1:(length(breaks)-1)],line5,col="gray60")
	lines(breaks[1:(length(breaks)-1)],line6,col="gray75")
	lines(c(log10(minReadsMapped),log10(minReadsMapped)),c(0,100000),col="red",lwd=2)
	lines(rep(log10(quantile(nMapped1,0.05)),2),c(0,100000),col="blue",lwd=2)
print (quantile(nMapped1,0.05))

}
