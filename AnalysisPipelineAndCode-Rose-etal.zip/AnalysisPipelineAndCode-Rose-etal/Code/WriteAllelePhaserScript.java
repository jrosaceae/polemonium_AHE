import java.io.*;

public class WriteAllelePhaserScript{

  public static void main(String[] args){
    try{

		
		String project = args[0];							//e.g. P0032
		int begSample = Integer.parseInt(args[1]);			//e.g. 2859
		int endSample = Integer.parseInt(args[2]);			//e.g. 2866
		//String refs = args[3];								//e.g. BirdRefs
		//int nRefs = Integer.parseInt(args[4]);				//e.g. 2
		//int nLoci = Integer.parseInt(args[5]);				//e.g. 403
		//int ram = Integer.parseInt(args[6]);				//e.g. 8000
		int jobs = Integer.parseInt(args[3]);				//e.g. 3
		
		//What I want to write: java -Xmx8000m Assembler ../I0001/I0001 ../References/BirdRefs.txt 2 403

		int nInds=0;
		for(int i=begSample; i<=endSample; i++){
			String ind=getSampleName(i);
			String filename="../"+ind+"/"+ind+"_M.fastq";
			if(new File(filename).exists()){
		 		nInds++;
			}
		}

		int jobCeiling=(int)(Math.ceil(nInds/(double)jobs));
		int jobFloor=(int)(Math.floor(nInds/(double)jobs));
		int remainder = nInds%jobs;

if(jobs>nInds){
	System.out.println("Warning: you need to specify one job then divide the jobs manually!");
	//should probably throw an exception here tho
}

		BufferedWriter bw=null;
		nInds=0;
		int nOutfiles=0;

		for(int i=begSample; i<=endSample; i++){

			String ind=getSampleName(i);
			String filename="../"+ind+"/"+ind+"_M.fastq";
			if(new File(filename).exists()){
		 		nInds++;
				if(nInds%jobCeiling==1 || jobCeiling == 1){
					if(bw!=null){bw.flush(); bw.close();}
					if(nOutfiles == remainder){jobCeiling = jobFloor; nInds = 1;}
					nOutfiles++;
					bw = new BufferedWriter ( new OutputStreamWriter(new FileOutputStream(   new File("AllelePhase_"+project+"_"+nOutfiles+".sh") ) ));
				}
				//java -Xmx16000m Assembler ../I#/I# ../References/ClitelataRefs.txt 3 594
				bw.write("java AllelePhaser3 ../"+ind+"/"+ind+" 20000 0.5 2\n");
				//bw.write("java -Xmx"+ram+"m Assembler ../"+ind+"/"+ind+" ../References/"+refs+".txt "+nRefs+" "+nLoci+"\n");

				bw.flush();
			}
		}		
		bw.flush();
		bw.close();

    }catch(IOException ioe){System.out.println(ioe);}
  }

  static String getSampleName(int i){
  	String sampleName;
	if(i<10){sampleName="I000"+i;
	}else if(i<100){sampleName="I00"+i;
	}else if(i<1000){sampleName="I0"+i;
	}else{sampleName="I"+i;}
//	}else if(i<10000){sampleName="I"+i;
//	}else{System.out.println("Sample number exceeds 9999. Good Job cranking through the samples, but code not equipt!"); return "BAD";}  	
	return sampleName;
  }
}
